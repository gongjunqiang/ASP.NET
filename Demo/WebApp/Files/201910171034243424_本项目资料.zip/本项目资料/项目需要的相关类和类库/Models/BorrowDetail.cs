﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Models
{
    /// <summary>
    /// 借阅详细表
    /// </summary>
    [Serializable]
    public class BorrowDetail
    {

    }
}
